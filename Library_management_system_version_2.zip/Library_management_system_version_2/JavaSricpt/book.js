document.addEventListener('DOMContentLoaded', () => {
    const libraryForm = document.getElementById('library-form');
    const libraryItemsList = document.getElementById('library-items');
    let editingItem = null;

    // Extended sample items
    const sampleItems = [
        { title: 'To Kill a Mockingbird', author: 'Harper Lee', genre: 'Fiction', cover: 'images/book1.jpg' },
        { title: '1984', author: 'George Orwell', genre: 'Dystopian', cover: 'images/book2.jpg' },
        { title: 'Moby Dick', author: 'Herman Melville', genre: 'Adventure', cover: 'images/book3.jpg' },
        { title: 'Pride and Prejudice', author: 'Jane Austen', genre: 'Romance', cover: 'images/book4.jpg' },
        { title: 'The Great Gatsby', author: 'F. Scott Fitzgerald', genre: 'Classic', cover: 'images/book5.jpg' },
        { title: 'War and Peace', author: 'Leo Tolstoy', genre: 'Historical', cover: 'images/book6.jpg' }
    ];

    // Initialize library with sample items
    sampleItems.forEach(item => addLibraryItem(item));

    libraryForm.addEventListener('submit', (event) => {
        event.preventDefault();

        const title = document.getElementById('book-title').value;
        const author = document.getElementById('book-author').value;
        const genre = document.getElementById('book-genre').value;
        const cover = document.getElementById('book-cover').files[0];

        if (title && author && genre && cover) {
            const reader = new FileReader();
            reader.onload = function (e) {
                const imgURL = e.target.result;
                if (editingItem) {
                    // Update existing item
                    editingItem.title = title;
                    editingItem.author = author;
                    editingItem.genre = genre;
                    editingItem.cover = imgURL;
                    updateLibraryItem(editingItem.element, editingItem);
                    editingItem = null;
                } else {
                    // Add new item
                    const newItem = { title, author, genre, cover: imgURL };
                    addLibraryItem(newItem);
                }
                libraryForm.reset();
            };
            reader.readAsDataURL(cover);
        }
    });

    function addLibraryItem(item) {
        const listItem = document.createElement('li');
        listItem.innerHTML = `
            <img src="${item.cover}" alt="${item.title}">
            <div class="item-info">
                <h3>${item.title}</h3>
                <p>${item.author}</p>
                <span class="genre">${item.genre}</span>
            </div>
            <div class="item-actions">
                <button class="edit">Edit</button>
                <button class="delete">Delete</button>
            </div>
        `;
        libraryItemsList.appendChild(listItem);

        // Add event listeners for delete and edit buttons
        listItem.querySelector('.delete').addEventListener('click', () => {
            listItem.remove();
        });

        listItem.querySelector('.edit').addEventListener('click', () => {
            document.getElementById('book-title').value = item.title;
            document.getElementById('book-author').value = item.author;
            document.getElementById('book-genre').value = item.genre;
            // Setting up image preview is omitted; consider implementing it if needed
            editingItem = {
                title: item.title,
                author: item.author,
                genre: item.genre,
                cover: item.cover,
                element: listItem
            };
        });
    }

    function updateLibraryItem(element, item) {
        element.querySelector('img').src = item.cover;
        element.querySelector('h3').textContent = item.title;
        element.querySelector('p').textContent = item.author;
        element.querySelector('.genre').textContent = item.genre;
    }
});
