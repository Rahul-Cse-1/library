document.addEventListener('DOMContentLoaded', () => {
    const options = document.querySelectorAll('.option');
    options.forEach(option => {
        option.addEventListener('click', () => {
            options.forEach(opt => opt.classList.remove('selected'));
            option.classList.add('selected');
            option.querySelector('input[type="radio"]').checked = true;
        });
    });

    const continueButton = document.getElementById('continue-button');
    continueButton.addEventListener('click', () => {
        const selectedOption = document.querySelector('.option.selected');
        if (selectedOption) {
            alert(`You have selected ${selectedOption.textContent.trim()}`);
        } else {
            alert('Please select a payment method.');
        }
    });
});
