document.getElementById('loginForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the default form submission

    var email = document.getElementById('email').value.trim();
    var password = document.getElementById('password').value.trim();
    var alertMessageDiv = document.getElementById('alertMessage');

    // Clear previous error messages
    document.getElementById('emailError').textContent = '';
    document.getElementById('passwordError').textContent = '';

    var isValid = true;

    // Email validation
    if (email === '') {
        document.getElementById('emailError').textContent = 'Email is required.';
        isValid = false;
    } else {
        var emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!emailPattern.test(email)) {
            document.getElementById('emailError').textContent = 'Please enter a valid email address.';
            isValid = false;
        }
    }

    // Password validation
    if (password === '') {
        document.getElementById('passwordError').textContent = 'Password is required.';
        isValid = false;
    } else if (password.length < 6) {
        document.getElementById('passwordError').textContent = 'Password must be at least 6 characters long.';
        isValid = false;
    }

    // Display appropriate message
    if (isValid) {
        alertMessageDiv.innerHTML = 'Login successful!';
        alertMessageDiv.style.display = 'block';
        alertMessageDiv.style.color = 'green';
    } else {
        alertMessageDiv.innerHTML = 'Please correct the highlighted errors and try again.';
        alertMessageDiv.style.display = 'block';
        alertMessageDiv.style.color = 'red';
    }
});