document.getElementById('searchForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent the form from submitting

    var searchInput = document.getElementById('searchInput').value.toLowerCase();
    var searchResults = document.getElementById('searchResults');
    searchResults.innerHTML = ''; // Clear previous results

    var books = [
        {
            title: 'It Starts With Us',
            author: 'Colleen Hoover',
            genre: 'Romance',
            image: 'Images/it_starts.jpg',
            detailsLink: '../HTML/login.html'
        },
        {
            title: 'Sherlock Holmes',
            author: 'Arthur Conan Doyle',
            genre: 'Mystery',
            image: 'Images/mystery.jpg',
            detailsLink: '#'
        },
        {
            title: 'It Ends With Us',
            author: 'Colleen Hoover',
            genre: 'Romance',
            image: 'Images/it_ends.jpg',
            detailsLink: '#'
        },
        // Add more book objects here
    ];

    var filteredBooks = books.filter(function(book) {
        return book.title.toLowerCase().includes(searchInput) ||
               book.author.toLowerCase().includes(searchInput) ||
               book.genre.toLowerCase().includes(searchInput);
    });

    if (filteredBooks.length > 0) {
        filteredBooks.forEach(function(book) {
            var bookItem = document.createElement('div');
            bookItem.classList.add('book-item');
            bookItem.innerHTML = `
                <img src="${book.image}" alt="${book.title}">
                <h4>${book.title}</h4>
                <p>Author: ${book.author}</p>
                <p>Genre: ${book.genre}</p>
                <a href="${book.detailsLink}" class="rounded-button">View Details</a>
            `;
            searchResults.appendChild(bookItem);
        });
    } else {
        searchResults.innerHTML = '<p>No results found.</p>';
    }
});
