function validateForm() {
    const firstName = document.getElementById('first-name').value;
    const lastName = document.getElementById('last-name').value;
    const userName = document.getElementById('user-name').value;
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirm-password').value;
    let isValid = true;

    // Reset error messages
    document.getElementById('first-name-error').innerText = '';
    document.getElementById('last-name-error').innerText = '';
    document.getElementById('user-name-error').innerText = '';
    document.getElementById('password-error').innerText = '';
    document.getElementById('confirm-password-error').innerText = '';
    document.getElementById('alert-message').innerText = '';

    if (firstName.length < 3) {
        document.getElementById('first-name-error').innerText = 'First name must be at least 3 characters long.';
        isValid = false;
    }
    if (lastName.length < 3) {
        document.getElementById('last-name-error').innerText = 'Last name must be at least 3 characters long.';
        isValid = false;
    }
    if (userName.length < 3) {
        document.getElementById('user-name-error').innerText = 'User name must be at least 3 characters long.';
        isValid = false;
    }
    if (password.length < 6) {
        document.getElementById('password-error').innerText = 'Password must be at least 6 characters long.';
        isValid = false;
    }
    if (password !== confirmPassword) {
        document.getElementById('confirm-password-error').innerText = 'Passwords do not match.';
        isValid = false;
    }

    if (isValid) {
        document.getElementById('alert-message').innerText = `Welcome, ${firstName} ${lastName}!\n\nThank you for registering with BookWave. We're thrilled to have you join our community of book lovers. Happy reading!`;
    }
    return isValid;
}
